// import 'package:flutter/material.dart';
//
// class TodoApp extends StatefulWidget {
//   const TodoApp({super.key});
//
//   @override
//   State<TodoApp> createState() => _TodoAppState();
// }
//
// class _TodoAppState extends State<TodoApp> {
//   final TextEditingController _controller = TextEditingController();
//
//   final List<String> _tasks = [];
//
//   void _addTask(String task) {
//     setState(() {
//       _tasks.add(task);
//     });
//     _controller.clear();
//   }
//
//   void _deleteTask(int index) {
//     setState(() {
//       _tasks.removeAt(index);
//     });
//   }
//
//   void _toggleTaskCompletion(int index) {
//     setState(() {
//       _tasks[index] = "✅ ${_tasks[index]}";
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         flexibleSpace: Container(
//           decoration: BoxDecoration(
//               gradient: LinearGradient(
//                   colors: [Colors.lightBlueAccent, Colors.pinkAccent],
//                   begin: Alignment.topLeft,
//                   end: Alignment.bottomRight)),
//         ),
//         title: Text('TODO LIST APP'),
//         centerTitle: true,
//       ),
//       body: Container(
//         decoration: BoxDecoration(
//             gradient: LinearGradient(
//                 colors: [Colors.lightBlueAccent, Colors.pinkAccent],
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight)),
//         child: Padding(
//           padding: const EdgeInsets.all(16.0),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text('Add a new task: ',
//                   style:
//                   TextStyle(fontSize: 18, fontWeight: FontWeight.w400)),
//               SizedBox(height: 10,),
//               Container(
//                 height: 100, // Adjust the height as needed
//                 child: TextFormField(
//                   controller: _controller,
//                 //  maxLines: null, // Allow multiple lines
//                   decoration: InputDecoration(
//                     border: OutlineInputBorder(), // Add border for visual clarity
//                     labelText: 'Task', // Add label text for the input field
//                   ),
//                   onFieldSubmitted: (value) {
//                     if (value.isNotEmpty) {
//                       _addTask(value);
//                     }
//                   },
//                 ),
//               ),
//               SizedBox(height: 20,),
//               Text('Tasks: ',
//                   style:
//                   TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
//               Expanded(
//                 child: ListView.builder(
//                   itemCount: _tasks.length,
//                   itemBuilder: (context, index) {
//                     return ListTile(
//                       title: Text(_tasks[index]),
//                       trailing: IconButton(
//                         icon: Icon(Icons.check),
//                         onPressed: () {
//                           _toggleTaskCompletion(index);
//                         },
//                       ),
//                       onLongPress: () {
//                         _deleteTask(index);
//                       },
//                     );
//                   },
//                 ),
//               ),
//               Text(
//                 'Note: ',
//                 style: TextStyle(
//                   fontWeight: FontWeight.w600,
//                   fontSize: 18,
//                 ),
//               ),
//               Text(
//                 'If you want to delete a task, long press on it. To mark a task as completed, click on the check icon.',
//                 style: TextStyle(
//                   fontSize: 18,
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';


class TodoApp extends StatefulWidget {
  const TodoApp({super.key});

  @override
  State<TodoApp> createState() => _TodoAppState();
}

class _TodoAppState extends State<TodoApp> {
  final TextEditingController _controller = TextEditingController();

  late SharedPreferences _prefs;
  List<String> _tasks = [];

  @override
  void initState() {
    super.initState();
    _initSharedPreferences();
  }

  Future<void> _initSharedPreferences() async {
    _prefs = await SharedPreferences.getInstance();
    _loadTasks();
  }

  Future<void> _loadTasks() async {
    setState(() {
      _tasks = _prefs.getStringList('tasks') ?? [];
    });
  }

  Future<void> _saveTasks() async {
    await _prefs.setStringList('tasks', _tasks);
  }

  void _addTask(String task) {
    setState(() {
      _tasks.add(task);
      _saveTasks();
    });
    _controller.clear();
  }

  void _deleteTask(int index) {
    setState(() {
      _tasks.removeAt(index);
      _saveTasks();
    });
  }

  void _toggleTaskCompletion(int index) {
    setState(() {
      if (_tasks[index].startsWith("✅")) {
        _tasks[index] = _tasks[index].substring(2); // Remove the checkmark if already present
      } else {
        _tasks[index] = "✅ ${_tasks[index]}"; // Add the checkmark if not present
      }
      _saveTasks();
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: [Colors.lightBlueAccent, Colors.pinkAccent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight)),
        ),
        title: Text('TODO LIST APP'),
        centerTitle: true,
          // leading: IconButton(
          //   icon: Icon(Icons.arrow_back),
          //   onPressed: () {
          //     Navigator.pop(context);
          //   },
          // ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.lightBlueAccent, Colors.pinkAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Add a new task:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w400),
              ),
              SizedBox(height: 10),
              Container(
                height: 100, // Adjust the height as needed
                child: TextFormField(
                  controller: _controller,
                   maxLines: null, // Allow multiple lines
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Task',
                  ),
                  onFieldSubmitted: (value) {
                    if (value.isNotEmpty) {
                      _addTask(value);
                    }
                  },
                ),
              ),
              SizedBox(height: 20),
          Center(
            child: ElevatedButton(
              onPressed: () {
                if (_controller.text.isNotEmpty) {
                  _addTask(_controller.text);
                }
              },
              child: Text('Add Task'),
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.resolveWith<Color>(
                      (Set<MaterialState> states) {
                    return Colors.green; // Default color
                  },
                ),
                overlayColor: MaterialStateProperty.resolveWith<Color>(
                      (Set<MaterialState> states) {
                    return Colors.grey; // Color when hovered
                  },
                ),
              ),
            ),
          ),


              SizedBox(height: 20),
              Text(
                'Tasks:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: _tasks.asMap().entries.map((entry) {
                      final index = entry.key;
                      final task = entry.value;
                      return ListTile(
                        title: Text(task),
                        trailing: IconButton(
                          icon: Icon(Icons.delete),
                          onPressed: () {
                            _deleteTask(index);
                          },
                        ),
                        onTap: () {
                          _toggleTaskCompletion(index);
                        },
                      );
                    }).toList(),
                  ),
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}


